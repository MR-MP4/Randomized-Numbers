# Charity: Water Game Mockup

## Files
- `index.html` — page structure and game interface
- `styles.css` — layout, colors, mockup-inspired visuals, and responsive styling
- `script.js` — starting game variables and button interactions

## Run it
Open `index.html` in a modern browser. No server or dependencies are required.

## Starting values
- Day: 1
- Budget: $100
- Builds: 0
- Sanitation: 0
- Agriculture: 0
- Education: 0

The background, worker, and Charity: Water artwork are placeholders labeled "Image here". Replace each placeholder element with an `<img>` when you have the real assets.

## Current button behavior
- Water Pump: costs $40; increases sanitation and agriculture by 2 each.
- Sanitation Station: costs $30; increases sanitation by 3.
- Advertise: costs $15; returns $30, for a net budget increase of $15.
- Educate: costs $20; increases education by 2.
- Next Day: advances the day counter.

Costs and rewards are grouped near the top of `script.js` so you can easily tune game balance.
